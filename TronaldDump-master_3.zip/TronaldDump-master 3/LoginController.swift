//
//  LoginController.swift
//  TronaldDump
//
//  Created by SUP'Internet 05 on 25/11/2019.
//  Copyright © 2019 Louis Loiseau-Billon. All rights reserved.
//

import UIKit

extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}


class LoginController: UIViewController, UITextFieldDelegate {
    
    let LoginTitle = UILabel()
    let EmailTitle = UITextField()
    let PasswordTitle = UITextField()
    
    @objc func redirectToList() {
        
        let token = ""
        let url = URL(string: "http://edu2.shareyourtime.fr/api/auth")!
        let json: [String: Any] = ["email": EmailTitle.text, "password": PasswordTitle.text]
        let jsonData = try? JSONSerialization.data(withJSONObject: json)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        request.httpBody = jsonData
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue( "Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            if let responseJSON = responseJSON as? [String: Any] {
                UserDefaults.standard.set(jsonData, forKey: "Key")
    
                 DispatchQueue.main.async {
                    self.performSegue(withIdentifier: "login_success", sender: self)
                    print(responseJSON)
                }
            }
        }
        
        task.resume()
        
        
        
    }
    
    
    override func viewDidLoad() {
        
        LoginTitle.text = "Login"
        LoginTitle.font = UIFont.boldSystemFont(ofSize: 35)
        
        
        
        EmailTitle.backgroundColor = UIColor.white.withAlphaComponent(0.75)
        EmailTitle.setLeftPaddingPoints(10)
        EmailTitle.layer.cornerRadius = 5
        EmailTitle.layer.borderWidth = 1.0
        EmailTitle.tag = 0
        EmailTitle.delegate = self
        EmailTitle.returnKeyType = UIReturnKeyType.next
        EmailTitle.keyboardType = UIKeyboardType.emailAddress
        EmailTitle.placeholder = "Email"
        
        
        
        PasswordTitle.backgroundColor = UIColor.white.withAlphaComponent(0.75)
        PasswordTitle.setLeftPaddingPoints(10)
        PasswordTitle.layer.cornerRadius = 5
        PasswordTitle.isSecureTextEntry = true
        PasswordTitle.tag = 1
        PasswordTitle.layer.borderWidth = 1.0
        PasswordTitle.delegate = self
        PasswordTitle.returnKeyType = UIReturnKeyType.next
        PasswordTitle.placeholder = "Mot de passe"
        
        
        let btn = UIButton()
        btn.backgroundColor = .yellow
        btn.layer.cornerRadius = 5
        btn.setTitle("Se connecter", for: .normal)
        
        self.view.grid(child: LoginTitle, x: 4.7, y: 0.5, width: 12, height: 1)
        self.view.grid(child: EmailTitle, x: 3, y: 4, width: 6, height: 0.7)
        self.view.grid(child: PasswordTitle, x: 3, y: 5, width: 6, height: 0.7)
        self.view.grid(child: btn, x: 3, y: 9, width: 6, height: 0.7)

        btn.addTarget(self, action: #selector(redirectToList), for: .touchUpInside)
        
       
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let nextTag = textField.tag + 1
        
        if let nextResponder = textField.superview?.viewWithTag(nextTag) {
            nextResponder.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
