//
//  CategoriesController.swift
//  TronaldDump
//
//  Created by Louis Loiseau-Billon on 31/10/2019.
//  Copyright © 2019 Louis Loiseau-Billon. All rights reserved.
//

import UIKit

class CategoriesController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Categ")
    }
    
}
